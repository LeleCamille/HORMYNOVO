const plantas = [
  {
    id: 1,
    nome: "Alface",
    especie: "Lactuca sativa"
  },
  {
    id: 2,
    nome: "Manjericão",
    especie: "Ocimum basilicum"
  },
  {
    id: 3,
    nome: "Cebolinha",
    especie: "Allium fistulosum"
  }
]

export default plantas