function Calendario() {
  return (
    <div>
      <h2>Calendário de Rega</h2>

      <p>
        Próxima rega: 15/06/2026
      </p>
    </div>
  )
}

export default Calendario