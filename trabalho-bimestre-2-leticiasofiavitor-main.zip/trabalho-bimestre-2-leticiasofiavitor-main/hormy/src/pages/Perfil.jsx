function Perfil() {
  return (
    <div>
      <h2>Perfil</h2>

      <p>Nome: Sofia</p>

      <p>Email: sofia@email.com</p>
    </div>
  )
}

export default Perfil