function Artigos() {
  return (
    <div>
      <h2>Artigos</h2>

      <ul>
        <li>Como cultivar alface</li>
        <li>Como regar corretamente</li>
        <li>Hortas em apartamentos</li>
      </ul>
    </div>
  )
}

export default Artigos