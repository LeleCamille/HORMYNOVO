function Footer() {
  return (
    <footer>
      <p>Hormy 2026</p>
    </footer>
  )
}

export default Footer