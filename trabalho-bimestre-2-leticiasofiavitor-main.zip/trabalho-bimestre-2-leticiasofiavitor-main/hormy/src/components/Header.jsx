function Header() {
  return (
    <header>
      <h1>Hormy 🌱</h1>
    </header>
  )
}

export default Header